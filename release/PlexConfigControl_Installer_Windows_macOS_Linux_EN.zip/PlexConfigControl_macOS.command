#!/bin/bash
set -eu

installer="$(cd "$(dirname "$0")" && pwd)/PlexConfigControl_Installer.py"
if [ ! -r "$installer" ]; then
    printf '%s\n' 'Extract the ZIP. Keep the .py installer next to this launcher.' >&2
    exit 1
fi
if ! command -v ssh >/dev/null || ! command -v scp >/dev/null; then
    printf '%s\n' 'OpenSSH Client is required for ssh and scp.' >&2
    exit 1
fi

read -r -p 'TrueNAS IPv4 address or hostname: ' host
read -r -p 'TrueNAS SSH user with sudo access: ' user
if [[ ! $host =~ ^[a-zA-Z0-9][a-zA-Z0-9.-]*$ || ! $user =~ ^[a-zA-Z_][a-zA-Z0-9_.-]*$ ]]; then
    printf '%s\n' 'Enter a valid address and username.' >&2
    exit 1
fi
destination="$user@$host"
local_dir=$(mktemp -d /tmp/pcc-ssh.XXXXXXXX)
control="$local_dir/session"
cleanup() {
    if [ -S "$control" ]; then
        ssh -S "$control" -O exit "$destination" >/dev/null 2>&1 || true
    fi
    rm -f -- "$control"
    rmdir -- "$local_dir" || true
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

# SSH prompts for authentication and verifies the host key itself.
ssh -M -N -f -o StrictHostKeyChecking=ask -o ControlPersist=no -o "ControlPath=$control" "$destination"
remote_dir=$(ssh -S "$control" "$destination" 'umask 077; mktemp -d /var/tmp/pcc-mac.XXXXXXXX')
if [[ ! $remote_dir =~ ^/var/tmp/pcc-mac\.[a-zA-Z0-9]{8}$ ]]; then
    printf '%s\n' 'TrueNAS did not return a valid temporary path.' >&2
    exit 1
fi
remote_file="$remote_dir/PlexConfigControl_Installer.py"
scp -o "ControlPath=$control" "$installer" "$destination:$remote_file"

if ssh -S "$control" -tt "$destination" "sudo python3 '$remote_file'"; then
    ssh -S "$control" "$destination" "rm -f -- '$remote_file' && rmdir -- '$remote_dir'" ||
        printf '%s\n' "The installer file is still on TrueNAS in $remote_dir."
else
    status=$?
    printf '%s\n' "The wizard stopped. The installer can be resumed on TrueNAS from $remote_dir."
    exit "$status"
fi
