"""Prepare verified storage and a Compose definition for TrueNAS Apps.

The Apps installer owns the managed iXVolume and the deployment job.
"""
import argparse
import ipaddress
import json
import os
import re
import ssl
import stat
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

from .catalog_bundle import APP, catalog_files, with_plex_sqlite
from .deployment import Deployment
from .installation_storage import create_storage, plan_storage
from .naming import save_naming
from .storage import verify_destination
from .plex_storage import _zfs
from .plex_runtime import PlexRuntimeError, detect_plex_runtime


APPS_MOUNT = '/mnt/.ix-apps'
SQLITE_INITIALIZER = Path(__file__).resolve().parents[1]/'design/truenas-installation/initialize-plex-sqlite.sh'
UID = 568
PRIVATE_FILES = {
    'api_key_file': ('truenas-key', UID, 0o600),
    'verifier_file': ('panel-verifier', UID, 0o600),
    'api_ca_file': ('truenas-ca.pem', 0, 0o644),
}
_READ_METHODS = {'system.version', 'docker.config', 'app.query', 'app.config',
                 'app.ix_volume.query', 'filesystem.statfs', 'core.get_jobs'}


class InstallError(RuntimeError):
    pass


class LocalMiddleware:
    """Fixed middleware verbs and argument lists, never shell evaluation."""
    def __init__(self, runner=subprocess.run):
        self.runner = runner

    def call(self, method, *params):
        if method not in _READ_METHODS:
            raise InstallError('Unsupported installer lookup')
        return self._call(method, params)

    def _call(self, method, params, *, job=False):
        command = ['midclt', 'call', *(['--job'] if job else []), method,
                   *(json.dumps(value) for value in params)]
        try:
            result = self.runner(command, check=True, capture_output=True, text=True,
                                 timeout=300 if job else 30)
            version = result.stdout.strip()
            if method == 'system.version' and version.startswith('TrueNAS-'):
                return version
            return json.loads(result.stdout)
        except (OSError, subprocess.SubprocessError, ValueError):
            raise InstallError(f'TrueNAS did not confirm {method}') from None

    def allocate_state(self, deployment, *, managed_private=False):
        name = deployment.panel_image.rsplit('/', 1)[-1]
        if ':' not in name or '@' in deployment.panel_image:
            raise InstallError('The locally built panel image requires an explicit tag')
        repository, tag = deployment.panel_image.rsplit(':', 1)
        volumes = [('state', '/var/lib/plexconfigcontrol')]
        if managed_private:
            volumes.append(('pcc', '/var/lib/plexconfigcontrol-private'))
        return self._call('app.create', ({
            'app_name': APP, 'catalog_app': 'ix-app', 'train': 'stable', 'version': '1.4.8',
            'values': {
                'image': {'repository': repository, 'tag': tag, 'pull_policy': 'never'},
                'entrypoint': ['/bin/sleep'], 'command': ['infinity'],
                'disable_builtin_healthcheck': True, 'restart_policy': 'no',
                'run_as_custom_user': True, 'run_as': {'user': UID, 'group': UID},
                'storage': [{'type': 'ix_volume', 'read_only': False, 'mount_path': mount,
                             'ix_volume_config': {'dataset_name': name, 'acl_enable': False}}
                            for name, mount in volumes],
            },
        },), job=True)

    def convert(self):
        return self._call('app.convert_to_custom', (APP,), job=True)

    def configure(self, compose):
        # Send the Compose object directly to middleware. The CLI can interpret
        # the serialized object containing the initializer as a string argument.
        from truenas_api_client import Client

        try:
            with Client() as client:
                return client.call('app.update', APP, {'custom_compose_config': compose}, job=True)
        except Exception:
            raise InstallError('TrueNAS did not confirm app.update') from None

    def stop(self):
        return self._call('app.stop', (APP,), job=True)

    def start(self):
        return self._call('app.start', (APP,), job=True)


def _verify_private_file(path, *, owner=None):
    path = Path(path)
    if path.resolve(strict=True) != path:
        raise InstallError('Installation files must use real paths')
    info = path.lstat()
    if not stat.S_ISREG(info.st_mode) or (owner is not None and
            (info.st_uid != owner or info.st_mode & 0o077 or not info.st_mode & stat.S_IRUSR)):
        raise InstallError('Invalid ownership or permissions on an installation file')


def _verify_local_images(deployment):
    try:
        subprocess.run(['docker', 'image', 'inspect', deployment.panel_image, deployment.worker_image],
                       check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=20)
    except (OSError, subprocess.SubprocessError):
        raise InstallError('The panel and worker images must be built locally before installation') from None


def form_settings(values, *, panel_image, worker_image, sqlite_version):
    """Translate native form values; package metadata supplies the image and SQLite versions."""
    panel, backup, connection, plex = (values[key] for key in ('panel', 'backup', 'connection', 'plex'))
    mode = plex.get('storage_mode', 'automatic')
    if mode not in ('automatic', 'manual') or (mode == 'manual' and not plex.get('manual_source')):
        raise InstallError('Choose automatic Plex detection or a valid manual path')
    address = ipaddress.ip_address(panel['host_ip'])
    api_host = f'[{address}]' if address.version == 6 else str(address)
    return {
        'panel_image': panel_image, 'worker_image': worker_image, 'sqlite_version': sqlite_version,
        'host_ip': panel['host_ip'], 'host_port': panel['host_port'], 'verifier_file': panel['verifier_file'],
        'archive_parent': backup['archive_parent'], 'folder_name': backup['folder_name'],
        'archive_prefix': backup['archive_prefix'],
        'api_url': connection.get('api_url') or f'wss://{api_host}/api/current',
        'api_user': connection['api_user'],
        'api_key_file': connection['api_key_file'], 'api_ca_file': connection['api_ca_file'],
        'manual_source': plex.get('manual_source') if mode == 'manual' else None,
    }


def require_truenas_version(version):
    match = re.fullmatch(r'TrueNAS-(\d+)\.(\d+)(?:\.(\d+))?', str(version))
    if match is None or tuple(int(part or 0) for part in match.groups()) < (25, 10, 8):
        raise InstallError('Wymagany jest TrueNAS 25.10.8 lub nowszy w wersji stabilnej.')


def _prepare(api, settings, *, provisioned=False, managed_private=False):
    require_truenas_version(api.call('system.version'))
    if not provisioned and api.call('app.query', [['name', '=', APP]], {'select': ['name']}) != []:
        raise InstallError('PlexConfigControl already exists or its name cannot be checked')
    apps_dataset, apps_mount = _zfs(api, APPS_MOUNT)
    docker = api.call('docker.config')
    if apps_mount != APPS_MOUNT or not isinstance(docker, dict) or docker.get('dataset') != apps_dataset:
        raise InstallError('The managed Apps dataset cannot be confirmed')
    state = APPS_MOUNT + '/app_mounts/' + APP + '/state'
    volumes = api.call('app.ix_volume.query', [['app_name', '=', APP]])
    if provisioned:
        expected = [{'app_name': APP, 'name': name} for name in
                    (('pcc', 'state') if managed_private else ('state',))]
        if sorted(volumes, key=lambda item: item['name']) != expected:
            raise InstallError('TrueNAS must provision the dedicated PlexConfigControl state volume first')
        if _zfs(api, state) != (f'{apps_dataset}/app_mounts/{APP}/state', state):
            raise InstallError('The managed state volume does not match the expected dataset')
    elif volumes != []:
        raise InstallError('A state volume already exists for PlexConfigControl or cannot be checked')
    data = dict(settings)
    archive_parent = data.pop('archive_parent')
    archive_dataset, archive_mount = _zfs(api, archive_parent)
    if archive_dataset == apps_dataset or archive_dataset.startswith(apps_dataset + '/'):
        raise InstallError('Choose archive storage outside the managed Apps dataset')
    storage = plan_storage(api, archive_parent, manual_source=data.pop('manual_source', None),
                           folder_name=data.pop('folder_name', None), archive_prefix=data.pop('archive_prefix', None))
    private_sources = {field: data[field] for field in PRIVATE_FILES}
    if managed_private:
        data.update({field: str(Path(state).with_name('pcc') / filename)
                     for field, (filename, _, _) in PRIVATE_FILES.items()})
    deployment = Deployment(**data, state=state,
                            archives=str(Path(storage.parent)/storage.naming.folder_name),
                            plex_config=storage.plex.source, plex_dataset=storage.plex.dataset)
    if archive_dataset == deployment.plex_dataset or archive_dataset.startswith(deployment.plex_dataset + '/'):
        raise InstallError('Archive storage must be separate from the Plex configuration dataset')
    for field, (_, owner, _) in PRIVATE_FILES.items():
        _verify_private_file(private_sources[field], owner=owner if owner == UID else None)
    _verify_local_images(deployment)
    return deployment, storage, (archive_dataset, archive_mount)


def prepare(api, settings, *, provisioned=False):
    """Read-only review. The provisioned form is used after Apps allocates the iXVolume."""
    return _prepare(api, settings, provisioned=provisioned)[0]


def prepare_compose(api, settings, expected, *, confirmed=False, managed_private=False):
    """Create the selected output once and render Compose after verifying both mounts."""
    if confirmed is not True or os.geteuid() != 0:
        raise InstallError('Explicit administrator confirmation is required')
    current = _prepare(api, settings, provisioned=True, managed_private=managed_private)
    if current != expected:
        raise InstallError('Installation settings changed after review')
    deployment, plan, archive_filesystem = current
    path = Path(deployment.state)
    if path.resolve(strict=True) != path:
        raise InstallError('The managed state path must not contain symlinks')
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        if os.listdir(fd):
            raise InstallError('The managed state volume is already in use')
        # Exclusive creation consumes the empty-volume prerequisite before any
        # output writes. A crash leaves a record for administrative review.
        marker = os.open('install-preparation', os.O_WRONLY | os.O_CREAT | os.O_EXCL |
                         os.O_NOFOLLOW, 0o600, dir_fd=fd)
        os.close(marker)
        os.fsync(fd)
        destination = create_storage(api, plan)
        if (str(destination.root) != deployment.archives or not verify_destination(destination)
                or _zfs(api, deployment.archives) != archive_filesystem):
            raise InstallError('The selected archive destination could not be verified')
        save_naming(path, plan.naming)
        os.chown('output-naming.json', UID, UID, dir_fd=fd, follow_symlinks=False)
        os.fchmod(fd, 0o700)
        os.fchown(fd, UID, UID)
        os.fsync(fd)
    finally:
        os.close(fd)
    return deployment.compose()


def prepare_catalog(api, settings, expected, values, template_root, version, output, *, confirmed=False):
    """Prepare a fresh archive directory and write the native Apps version files."""
    if confirmed is not True or os.geteuid() != 0:
        raise InstallError('Explicit administrator confirmation is required')
    current = _prepare(api, settings)
    if current != expected:
        raise InstallError('Installation settings changed after review')
    deployment, plan, archive_filesystem = current
    plex_reference, sqlite_version, _, _ = detect_plex_runtime()
    if deployment.sqlite_version != sqlite_version:
        raise InstallError('The catalog SQLite version does not match the running Plex image')
    files = catalog_files(template_root, deployment, plan, values, version, plex_reference=plex_reference)
    output = Path(output).absolute()
    if output.parent.resolve(strict=True) != output.parent:
        raise InstallError('The catalog output must use a real parent directory')
    for path in map(Path, (deployment.state, deployment.archives, deployment.plex_config)):
        if output == path or output in path.parents or path in output.parents:
            raise InstallError('The catalog output overlaps application storage')
    output.mkdir(mode=0o700)  # Exclusive reservation. Never overwrite a prior export.
    destination = create_storage(api, plan)
    if (str(destination.root) != deployment.archives or not verify_destination(destination)
            or _zfs(api, deployment.archives) != archive_filesystem):
        raise InstallError('The selected archive destination could not be verified')
    for name, body in files.items():
        path = output/name
        path.parent.mkdir(exist_ok=True)
        with path.open('x', encoding='utf-8') as stream:
            stream.write(body)
    return output


def _ready(deployment, *, timeout=90):
    from .setup_protocol import emit
    emit('stage', code='VERIFY_APP')
    host = ipaddress.ip_address(deployment.host_ip)
    authority = f'[{host}]' if host.version == 6 else str(host)
    deadline = time.monotonic() + timeout
    while time.monotonic() < deadline:
        try:
            ca = Path(deployment.state)/'tls'/'panel.crt'
            context = ssl.create_default_context(cafile=str(ca))
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}),
                                                  urllib.request.HTTPSHandler(context=context))
            with opener.open(f'https://{authority}:{deployment.host_port}/healthz', timeout=5) as response:
                if json.loads(response.read(256)) == {'ready': True, 'mode': 'operational'}:
                    return
        except (OSError, ValueError):
            pass
        time.sleep(1)
    raise InstallError('TrueNAS created the app, but the panel and worker did not report readiness')


def _store_managed_private(api, deployment, values):
    private = Path(deployment.state).with_name('pcc')
    dataset = api.call('docker.config')['dataset']
    if (private.resolve(strict=True) != private
            or _zfs(api, str(private)) != (f'{dataset}/app_mounts/{APP}/pcc', str(private))):
        raise InstallError('The managed private iXVolume could not be verified')
    info = private.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != 0 or any(private.iterdir()):
        raise InstallError('The managed private iXVolume must be empty and owned by root')
    private.chmod(0o700)
    source_settings = {**values['panel'], **values['connection']}
    for field, (filename, owner, mode) in PRIVATE_FILES.items():
        source = Path(source_settings[field])
        _verify_private_file(source, owner=owner if owner == UID else None)
        target = private / filename
        fd = os.open(target, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, mode)
        with os.fdopen(fd, 'wb') as stream:
            os.fchown(stream.fileno(), owner, owner)
            os.fchmod(stream.fileno(), mode)
            stream.write(source.read_bytes())
            stream.flush()
            os.fsync(stream.fileno())
    stored = {**values, 'panel': {**values['panel'], 'verifier_file': deployment.verifier_file},
              'connection': {**values['connection'], 'api_key_file': deployment.api_key_file,
                             'api_ca_file': deployment.api_ca_file}}
    fd = os.open(private / 'settings.json', os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    with os.fdopen(fd, 'w', encoding='utf-8') as stream:
        json.dump(stored, stream, indent=2)
        stream.flush()
        os.fsync(stream.fileno())
    fd = os.open(private, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def install_app(api, settings, expected, *, confirmed=False, plex_reference=None, managed_values=None):
    """Install once under a fixed Apps name. Interrupted installs are never replayed."""
    if confirmed is not True or os.geteuid() != 0:
        raise InstallError('Explicit administrator confirmation is required')
    managed = managed_values is not None
    current = _prepare(api, settings, managed_private=True) if managed else _prepare(api, settings)
    if current != expected:
        raise InstallError('Installation settings changed after review')
    deployment = expected[0]
    bootstrap = api.allocate_state(deployment, managed_private=True) if managed else api.allocate_state(deployment)
    if not isinstance(bootstrap, dict) or bootstrap.get('name') != APP or bootstrap.get('custom_app') is not False:
        raise InstallError('TrueNAS did not confirm the state allocation app')
    if managed:
        compose = prepare_compose(api, settings, expected, confirmed=True, managed_private=True)
        _store_managed_private(api, deployment, managed_values)
    else:
        compose = prepare_compose(api, settings, expected, confirmed=True)
    if plex_reference is not None:
        compose = with_plex_sqlite(deployment.compose(), plex_reference,
            deployment.sqlite_version, SQLITE_INITIALIZER.read_text(encoding='utf-8'))
    converted = api.convert()
    if not isinstance(converted, dict) or converted.get('name') != APP or converted.get('custom_app') is not True:
        raise InstallError('TrueNAS did not confirm conversion of PlexConfigControl')
    installed = api.configure(compose)
    if not isinstance(installed, dict) or installed.get('name') != APP or installed.get('custom_app') is not True:
        raise InstallError('TrueNAS did not confirm the final PlexConfigControl configuration')
    if installed.get('state') == 'STOPPED':
        api.start()
    _ready(deployment)
    return {'app': APP, 'host_ip': deployment.host_ip, 'port': deployment.host_port}

def main(argv=None):
    parser = argparse.ArgumentParser(description='Verify the PlexConfigControl installation form')
    parser.add_argument('configuration', type=Path)
    parser.add_argument('--panel-image', required=True)
    parser.add_argument('--worker-image', required=True)
    parser.add_argument('--sqlite-version', required=True)
    parser.add_argument('--plex-runtime', help=argparse.SUPPRESS)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--prepare-compose', action='store_true',
                      help='Prepare the confirmed paths after Apps provisions the iXVolume')
    mode.add_argument('--install', action='store_true',
                      help='Install the reviewed configuration as one application in TrueNAS Apps')
    parser.add_argument('--confirmed', action='store_true', help=argparse.SUPPRESS)
    parser.add_argument('--managed-private', action='store_true', help=argparse.SUPPRESS)
    mode.add_argument('--prepare-catalog', type=Path, metavar='OUTPUT',
                      help='Prepare a native Apps version directory for the reviewed settings')
    parser.add_argument('--catalog-template', type=Path)
    parser.add_argument('--catalog-version', default='0.1.0')
    args = parser.parse_args(argv)
    if (args.confirmed or args.managed_private) and not args.install:
        parser.error('--confirmed and --managed-private require --install')
    try:
        with args.configuration.open(encoding='utf-8') as stream:
            values = json.load(stream)
        settings = form_settings(values, panel_image=args.panel_image,
                                 worker_image=args.worker_image, sqlite_version=args.sqlite_version)
        api = LocalMiddleware()
        prepared = _prepare(api, settings, provisioned=args.prepare_compose, managed_private=args.managed_private)
        deployment, storage, _ = prepared
        review = {'app': APP, 'state': deployment.state, 'archives': deployment.archives,
                  'logs': deployment.archives + '/Logs', 'archive_prefix': storage.naming.archive_prefix,
                  'plex_dataset': deployment.plex_dataset,
                  'host_ip': deployment.host_ip, 'host_port': deployment.host_port}
        if args.prepare_compose or args.prepare_catalog or args.install:
            if args.prepare_catalog and args.catalog_template is None:
                raise InstallError('The catalog template directory is required')
            if not args.confirmed:
                print(json.dumps(review, indent=2), file=sys.stderr)
                if input(f'Wpisz {APP}, aby zatwierdzić wskazane ścieżki: ') != APP:
                    return 1
            if args.install:
                reference = None
                if args.plex_runtime is not None:
                    runtime = detect_plex_runtime()
                    if ' '.join(runtime) != args.plex_runtime or runtime[1] != deployment.sqlite_version:
                        raise InstallError('Plex zmienił się od czasu budowy obrazu. Uruchom instalator ponownie.')
                    reference = runtime[0]
                result = install_app(api, settings, prepared, confirmed=True, plex_reference=reference,
                                     managed_values=values if args.managed_private else None)
                if args.plex_runtime:
                    address = ipaddress.ip_address(result['host_ip'])
                    host = f'[{address}]' if address.version == 6 else str(address)
                    print(f"PlexConfigControl gotowy. Otwórz https://{host}:{result['port']}")
                else:
                    print(json.dumps(result))
            elif args.prepare_catalog:
                output = prepare_catalog(api, settings, prepared, values, args.catalog_template,
                                         args.catalog_version, args.prepare_catalog, confirmed=True)
                print(json.dumps({'catalog_version_directory': str(output)}))
            else:
                compose = prepare_compose(api, settings, prepared, confirmed=True)
                print(json.dumps(compose, indent=2))
        else:
            print(json.dumps(review, indent=2))
        return 0
    except (InstallError, PlexRuntimeError) as error:
        print(str(error), file=sys.stderr)
    except Exception:
        print('PlexConfigControl could not prepare the installation. Check the reviewed paths before retrying.', file=sys.stderr)
    return 1


if __name__ == '__main__':
    raise SystemExit(main())
