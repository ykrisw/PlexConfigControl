// QNAP session and destination controls. No NAS credentials are persisted.
const bar=document.createElement('div');bar.className='pcc-qnap-controls';bar.hidden=true;
bar.innerHTML='<button type="button" data-qnap-control data-auth></button><button type="button" data-qnap-control data-folder></button><button type="button" data-qnap-control data-recover hidden></button><button type="button" data-qnap-control data-restore-rollback hidden></button><button type="button" data-qnap-control data-restore-accept hidden></button><p role="status" data-error></p>';
const dialog=document.createElement('dialog');dialog.className='pcc-qnap-dialog';document.body.append(dialog);
let language='en',csrf=null,info=null,working=false,authenticated=false;
const tx=(en,pl)=>language==='pl'?pl:en;
const error=bar.querySelector('[data-error]');
const auth=bar.querySelector('[data-auth]'),folder=bar.querySelector('[data-folder]'),recover=bar.querySelector('[data-recover]');
function placeControls(){
  const target=document.querySelector('[data-panel=dashboard] .pcc-account-actions');
  if(target&&bar.parentElement!==target)target.prepend(bar);
  bar.hidden=!authenticated||!target;
  dialog.dataset.theme=document.querySelector('.pcc-shell')?.dataset.theme||'system';
  if(!target&&dialog.open)close();
}
const rollback=bar.querySelector('[data-restore-rollback]'),accept=bar.querySelector('[data-restore-accept]');
const root=document.getElementById('pcc-app');
if(root)new MutationObserver(placeControls).observe(root,{childList:true,subtree:true,attributes:true,attributeFilter:['data-theme']});
placeControls();
async function request(path,data){
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),55000);
  try{
    const response=await fetch(path,{method:data?'POST':'GET',credentials:'same-origin',cache:'no-store',signal:controller.signal,
      headers:data?{'Content-Type':'application/json','X-CSRF-Token':csrf}:undefined,...(data?{body:JSON.stringify(data)}:{})});
    const result=await response.json();
    if(response.status===401){authenticated=false;csrf=null;bar.hidden=true;close();}
    if(!response.ok)throw Error(result.error||tx('Request failed','Żądanie nie powiodło się'));
    return result;
  }finally{clearTimeout(timer);}
}
function close(){dialog.querySelectorAll('input[type=password]').forEach(input=>input.value='');dialog.close();dialog.replaceChildren();}
dialog.addEventListener('cancel',event=>{if(working)event.preventDefault();else close();});
function render(){
  auth.textContent=info?.authenticated?tx('QNAP signed in','QNAP zalogowany'):tx('Sign in to QNAP','Zaloguj do QNAP');
  folder.textContent=tx('Archive folder','Folder kopii');recover.textContent=tx('Recover interrupted operation','Odzyskaj stan przerwanej operacji');
  rollback.textContent=tx('Restore previous configuration','Wróć do poprzedniej konfiguracji');
  accept.textContent=tx('Confirm review and remove retained copy','Potwierdź sprawdzenie i usuń poprzednią kopię');
  for(const button of [rollback,accept]){button.hidden=!info?.restore_review||info?.recovery_required;button.disabled=working||info?.busy||!info?.authenticated;}
  auth.title=info?.username||tx('Sign in to QNAP','Zaloguj do QNAP');
  folder.title=info?.location?.path||tx('Choose a share and archive folder','Wybierz udział i folder kopii');
  placeControls();
  auth.disabled=working||info?.busy;folder.disabled=working||!info?.authenticated||info?.busy||info?.recovery_required||info?.restore_review||info?.restore_preparation;
  recover.hidden=!info?.recovery_required;recover.disabled=working||info?.busy||!info?.authenticated;
}
function form(title,fields){
  close();dialog.innerHTML='<form><h2></h2><div data-fields></div><p role="alert"></p><div class="pcc-qnap-actions"><button type="button" data-cancel></button><button type="submit"></button></div></form>';
  dialog.querySelector('h2').textContent=title;dialog.querySelector('[data-fields]').innerHTML=fields;
  dialog.querySelector('[data-cancel]').textContent=tx('Cancel','Anuluj');dialog.querySelector('[type=submit]').textContent=tx('Save','Zapisz');
  dialog.querySelector('[data-cancel]').onclick=()=>{if(!working)close();};dialog.showModal();
  return dialog.querySelector('form');
}
async function submit(form,action){
  working=true;form.querySelectorAll('button').forEach(el=>el.disabled=true);render();
  try{await action();close();error.textContent='';await poll();}
  catch(failure){form.querySelectorAll('input[type=password]').forEach(input=>input.value='');form.querySelector('[role=alert]').textContent=failure.name==='AbortError'?tx('Response not confirmed. Refresh operation status before retrying.','Nie potwierdzono odpowiedzi. Odśwież stan operacji przed ponowieniem.'):failure.message;}
  finally{working=false;form.querySelectorAll('button').forEach(el=>el.disabled=false);render();}
}
auth.onclick=()=>{
  const f=form(tx('QNAP administrator access','Dostęp administratora QNAP'),
    `<label>${tx('Local QNAP username','Lokalny użytkownik QNAP')}<input name="username" autocomplete="username" required maxlength="128"></label><label>${tx('QNAP password','Hasło QNAP')}<input name="password" type="password" autocomplete="off" required maxlength="4096"></label><label>${tx('Current TOTP (if enabled)','Aktualny TOTP (jeśli włączony)')}<input name="totp" type="password" inputmode="numeric" autocomplete="off" pattern="[0-9]{6}" maxlength="6"></label><small>${tx('Password and TOTP are used for this sign-in only. Sign in again after restarting the application.','Hasło i TOTP służą tylko do tego logowania. Po restarcie aplikacji zaloguj się ponownie.')}</small>`);
  f.elements.username.value=info?.username||'';f.querySelector('[type=submit]').textContent=tx('Sign in','Zaloguj');
  f.onsubmit=event=>{event.preventDefault();void submit(f,async()=>{
    const data=Object.fromEntries(new FormData(f));f.elements.password.value='';f.elements.totp.value='';
    try{await request('/api/qnap/auth',data);}finally{data.password='';data.totp='';}
  });};
};
folder.onclick=async()=>{
  try{
    const shares=await request('/api/qnap/shares');if(!authenticated)return;
    const f=form(tx('Archive destination','Miejsce zapisu kopii'),`<label>${tx('SMB share','Udział SMB')}<select name="share_id" required></select></label><label>${tx('Folder in the share','Folder w udziale')}<input name="folder" required maxlength="80"></label><small>${tx('A new folder will be created if needed. Operation logs remain in its Logs subfolder.','W razie potrzeby powstanie nowy folder. Logi operacji pozostają w jego podfolderze Logs.')}</small>`);
    for(const row of shares){const option=document.createElement('option');option.value=row.id;option.textContent=row.name;f.elements.share_id.append(option);}
    if(info?.location?.share_id)f.elements.share_id.value=info.location.share_id;
    f.elements.folder.value=info?.location?.folder||'Plex Config';
    f.onsubmit=event=>{event.preventDefault();void submit(f,()=>request('/api/qnap/configure',Object.fromEntries(new FormData(f))));};
  }catch(failure){error.textContent=failure.message;}
};
recover.onclick=()=>{
  const f=form(tx('Recover the recorded operation','Odzyskaj stan zapisanej operacji'),`<p>${tx('For interrupted Restore, stop Plex manually first. Recovery returns to the previous configuration, verifies it, and removes only the recorded snapshot and private workspace. For Backup, it reconciles only its recorded temporary files and snapshot.',
    'Po przerwanym Restore najpierw zatrzymaj Plex ręcznie. Odzyskiwanie wróci do poprzedniej konfiguracji, sprawdzi ją i usunie wyłącznie zapisaną migawkę oraz prywatny folder roboczy. Dla Backup sprawdzi wyłącznie jego zapisane pliki tymczasowe i migawkę.')}</p>`);
  f.onsubmit=event=>{event.preventDefault();void submit(f,()=>request('/api/qnap/recover',{confirmed:true}));};
};
rollback.onclick=()=>{
  const f=form(tx('Return to previous configuration','Wróć do poprzedniej konfiguracji'),`<p>${tx('Stop Plex manually in QNAP App Center first. This replaces the restored configuration with the retained original. Start Plex manually after rollback completes.','Najpierw zatrzymaj Plex ręcznie w QNAP App Center. Ta operacja zastąpi przywróconą konfigurację zachowaną poprzednią. Po zakończeniu powrotu uruchom Plex ręcznie.')}</p>`);
  f.onsubmit=event=>{event.preventDefault();void submit(f,()=>request('/api/qnap/restore-review',{action:'rollback',confirmed:true}));};
};
accept.onclick=()=>{
  const f=form(tx('Confirm Restore review','Potwierdź sprawdzenie Restore'),`<p>${tx('Confirm that you started Plex and checked libraries, playback and transcoding. This permanently removes the retained previous configuration and private staging files. The restored live configuration and source archive remain.','Potwierdź, że uruchomiłeś Plex i sprawdziłeś biblioteki, odtwarzanie oraz transkodowanie. Ta operacja trwale usunie zachowaną poprzednią konfigurację i prywatne pliki robocze. Działająca przywrócona konfiguracja i źródłowe archiwum pozostaną.')}</p>`);
  f.onsubmit=event=>{event.preventDefault();void submit(f,()=>request('/api/qnap/restore-review',{action:'accept',confirmed:true}));};
};
async function poll(){
  try{
    const session=await request('/api/session');csrf=session.csrf;authenticated=true;placeControls();
    const prefs=await request('/api/settings');language=prefs.language;
    info=await request('/api/qnap/info');error.textContent=info.error||'';render();
  }catch(failure){if(authenticated)error.textContent=failure.message;}
}
await poll();setInterval(()=>{if(!working)void poll();},5000);
