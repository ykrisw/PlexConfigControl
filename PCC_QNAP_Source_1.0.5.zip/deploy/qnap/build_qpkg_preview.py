#!/usr/bin/env python3
"""Build a native QNAP Backup/Restore QPKG with QNAP QDK."""
import argparse
import hashlib
import json
import io
import gzip
import os
from pathlib import Path
import re
import shlex
import shutil
import subprocess
import sys
import tarfile

ROOT=Path(__file__).resolve().parents[2]
PYTHON_SHA256='c2f87d4b4e8db3abddb0f116c6ccfc503d0cbdbb9ee8faacddad1b679ec12e99'
PYTHON_SOURCE='https://github.com/astral-sh/python-build-standalone/releases/download/20261110/cpython-3.12.16%2B20261110-x86_64-unknown-linux-gnu-install_only.tar.gz'


def digest(path):
    with Path(path).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()


def copytree(source,target):
    shutil.copytree(source,target,symlinks=True,ignore=shutil.ignore_patterns('__pycache__','*.pyc'))


def patch_qdk_loader(source):
    lines=source.splitlines(keepends=True)
    index=next(i for i,line in enumerate(lines) if 'count=$((($data_len + 1023) / 1024))' in line)
    assert "'rw+'" in lines[index+1]
    replacement=r'''
    data_len=$data_len
    /usr/local/bin/python3 -c "import sys
with open(sys.argv[1], 'rb') as src, open(sys.argv[2], 'wb') as dst:
    src.seek(int(sys.argv[3]))
    remaining = int(sys.argv[4])
    while remaining:
        chunk = src.read(min(1048576, remaining))
        if not chunk: raise SystemExit('Truncated QPKG payload')
        dst.write(chunk)
        remaining -= len(chunk)
" "\${0}" "\$_EXTRACT_DIR/$QDK_COMPRESS_FILE" "\$offset" "\$data_len" || exit 1
'''
    lines[index:index+2]=[replacement]
    return ''.join(lines)


def verify_package(package,unpacked):
    unpacked.mkdir()
    with package.open('rb') as source:
        header=source.read(32768).split(b'\nexit 1\n')[0]
        script=int(re.search(rb'^script_len=(\d+)$',header,re.M)[1])
        control=int(re.search(rb'expr \$script_len \+ (\d+)',header)[1])
        size=int(re.search(rb'^\s*data_len=(\d+)$',header,re.M)[1])
        source.seek(script)
        with tarfile.open(fileobj=io.BytesIO(source.read(control))) as outer:
            payload=outer.extractfile('control.tar.gz').read()
        with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as inner:
            inner.extractall(unpacked,filter='data')
        source.seek(script+control)
        with (unpacked/'data.tar.gz').open('wb') as output:
            remaining=size
            while remaining:
                chunk=source.read(min(1024*1024,remaining))
                if not chunk:raise ValueError('Truncated QPKG payload')
                output.write(chunk);remaining-=len(chunk)
    return unpacked/'data.tar.gz'


def build(python_archive,dependencies,qdk,output,private_tar):
    python_archive,dependencies,qdk,output=map(lambda p:Path(p).resolve(),(python_archive,dependencies,qdk,output))
    if output.exists():raise ValueError('Output already exists')
    if digest(python_archive)!=PYTHON_SHA256:raise ValueError('Private Python hash mismatch')
    manifest=json.loads((dependencies/'pcc-dependency-manifest.json').read_text())
    for name,expected in manifest['files'].items():
        if digest(dependencies/name)!=expected:raise ValueError('Private dependency hash mismatch: '+name)
    output.mkdir(parents=True)
    project=output/'project';project.mkdir()
    payload=project/'x86_64';payload.mkdir()
    (project/'shared').mkdir()
    with tarfile.open(python_archive,'r:gz') as tar:tar.extractall(payload,filter='data')
    python=payload/'python'
    # No pip/site packages from the runtime distribution; use our hash-locked lib.
    for item in [python/'include',python/'share',python/'lib/python3.12/site-packages',
                 python/'lib/python3.12/test',python/'lib/python3.12/idlelib',
                 python/'lib/python3.12/tkinter',python/'lib/python3.12/turtledemo',
                 python/'lib/python3.12/ensurepip']:
        if item.is_dir():shutil.rmtree(item)
    for file in (python/'bin').iterdir():
        if file.name not in ('python3','python3.12'):file.unlink()
    for file in python.rglob('*.a'):file.unlink()
    for file in python.rglob('*.pyc'):file.unlink()
    # This distribution's executable is statically linked to libpython.
    # The server does not use GUI/crypt/dbm extension modules. Avoid shipping
    # a second interpreter library, GUI libraries, headers and debug symbols.
    dynamic=subprocess.check_output(['readelf','-d',str(python/'bin/python3.12')],text=True)
    if 'Shared library: [libpython' in dynamic:raise ValueError('Unexpected dynamic Python runtime')
    for item in list((python/'lib').iterdir()):
        if item.name!='python3.12':
            if item.is_symlink() or item.is_file():item.unlink()
            elif item.is_dir():shutil.rmtree(item)
    for item in (python/'lib/python3.12/lib-dynload').glob('*.so'):
        if item.name.startswith(('_tkinter.','_crypt.','_dbm.')):item.unlink()
    subprocess.run(['strip','--strip-debug',str(python/'bin/python3.12')],check=True)
    copytree(dependencies,payload/'lib')
    (payload/'app').mkdir()
    copytree(ROOT/'plexconfigcontrol',payload/'app/plexconfigcontrol')
    private_tar=Path(private_tar).resolve()
    manifest=json.loads((private_tar/'SHA256-MANIFEST.json').read_text())
    if manifest['bin/pcc-tar']!='c7dc25fa1b3c55399081637652a2001e96518073bd7111509ec2ff481a9d5a28':raise ValueError('Untrusted GNU tar build')
    for name,expected in manifest.items():
        if Path(name).is_absolute() or '..' in Path(name).parts or digest(private_tar/name)!=expected:raise ValueError('Private GNU tar source/hash mismatch')
    copytree(private_tar,payload/'tar')
    for name in ('launcher.py','setup.html','PCC.sh'):
        shutil.copy2(ROOT/'deploy/qnap/qpkg'/name,payload/name)
    for name in ('qpkg.cfg','package_routines'):
        shutil.copy2(ROOT/'deploy/qnap/qpkg'/name,project/name)
    (payload/'PCC.sh').chmod(0o755)
    shutil.copy2(ROOT/'LICENSE',payload/'LICENSE')
    (payload/'build-sources').mkdir()
    shutil.copy2(Path(__file__),payload/'build-sources/build_qpkg_preview.py')
    shutil.copy2(qdk/'shared/scripts/qinstall.sh',payload/'build-sources/qinstall.sh')
    (payload/'BUILD-SOURCES.json').write_text(json.dumps({
        'python':{'url':PYTHON_SOURCE,'sha256':PYTHON_SHA256},
        'qdk_commit':subprocess.check_output(['git','-C',str(qdk),'rev-parse','HEAD'],text=True).strip(),
        'application_commit':subprocess.check_output(['git','-C',str(ROOT),'rev-parse','HEAD'],text=True).strip(),
        'scope':'snapshot Backup and journaled subtree Restore enabled; overwrite and archive deletion disabled',
    },indent=2)+'\n')
    subprocess.run([str(python/'bin/python3'),'-I','-S',str(payload/'launcher.py'),'--self-test'],check=True)
    for file in payload.rglob('*.pyc'):file.unlink()
    # Validate every shipped ELF's architecture and ABI ceiling against this NAS.
    elf_count=0
    for file in payload.rglob('*'):
        if not file.is_file() or file.is_symlink():continue
        with file.open('rb') as stream:header=stream.read(20)
        if not header.startswith(b'\x7fELF'):continue
        if header[4:6]!=b'\x02\x01' or int.from_bytes(header[18:20],'little')!=62:
            raise ValueError('Non-x86_64 ELF in payload: '+str(file))
        versions=subprocess.check_output(['readelf','--version-info',str(file)],text=True)
        required=[tuple(map(int,v.split('.'))) for v in re.findall(r'GLIBC_([0-9.]+)',versions)]
        if required and max(required)>(2,39):raise ValueError('glibc ABI too new: '+str(file))
        elf_count+=1
    print('ELF architecture/ABI checks passed:',elf_count,flush=True)
    tools=output/'qdk-tool';copytree(qdk/'shared',tools)
    (tools/'qdk.conf').write_text('QDK_VERSION=2.5.3\nQDK_PATH='+shlex.quote(str(tools))+'\n')
    shim=tools/'bin/rsync-build-shim'
    shim.write_text('#!'+sys.executable+'\n'+'''import sys,shutil
from pathlib import Path
args=sys.argv[1:]
for arg in args[:-2]:
    if arg not in ('-av','-q','--exclude=.svn'):raise SystemExit('Unexpected build-copy option')
source,target=map(Path,args[-2:])
shutil.copytree(source,target,dirs_exist_ok=True,symlinks=True,ignore=shutil.ignore_patterns('.svn'))
''')
    shim.chmod(0o755)
    qbuild=tools/'bin/qbuild';source=qbuild.read_text()
    assert source.count('/usr/bin/rsync')==1
    qbuild.write_text(patch_qdk_loader(source.replace('/usr/bin/rsync',str(shim))))
    subprocess.run(['cc','-O2','-o',str(tools/'bin/qpkg_encrypt'),str(qdk/'src/qpkg_encrypt.c')],check=True)
    environment={**os.environ,'PATH':str(tools/'bin')+':'+os.environ['PATH'],
                 'QDK_USER_CONFIG_FILE':'/dev/null'}
    release=output/'release'
    subprocess.run(['bash',str(qbuild),'--root',str(project),'--build-arch','x86_64',
                    '--build-dir',str(release),'--gzip'],cwd=project,env=environment,check=True)
    package=next(release.glob('*.qpkg'))
    unpacked=output/'verified-qpkg'
    data=verify_package(package,unpacked)
    if not data.is_file():raise ValueError('QPKG data archive missing')
    with tarfile.open(data) as tar:
        members=tar.getnames()
        for required in ('./launcher.py','./PCC.sh','./setup.html','./python/bin/python3.12',
                         './app/plexconfigcontrol/web.py','./app/plexconfigcontrol/qnap_service.py','./app/plexconfigcontrol/qnap_web.py','./app/plexconfigcontrol/qnap_restore.py',
                         './tar/bin/pcc-tar','./app/plexconfigcontrol/static/qnap-tools.mjs'):
            if required not in members:raise ValueError('Missing installed asset: '+required)
    with gzip.open(data,'rb') as stream:
        while stream.read(1024*1024):pass
    info={'file':str(package),'sha256':digest(package),'bytes':package.stat().st_size,
          'abi_elf_files':elf_count,'kind':'native-qnap-backup-restore'}
    (release/'build-result.json').write_text(json.dumps(info,indent=2)+'\n')
    print(json.dumps(info),flush=True)
    return package


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--python-archive',required=True,type=Path)
    parser.add_argument('--dependencies',required=True,type=Path)
    parser.add_argument('--qdk',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--private-tar',required=True,type=Path)
    args=parser.parse_args()
    build(args.python_archive,args.dependencies,args.qdk,args.output,args.private_tar)
