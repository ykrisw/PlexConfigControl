#!/bin/sh
set -eu
umask 077
QPKG_NAME=PCC
QPKG_ROOT=$(/sbin/getcfg "$QPKG_NAME" Install_Path -f /etc/config/qpkg.conf)
case "$QPKG_ROOT" in /share/*/.qpkg/PCC) ;; *) exit 1;; esac
PYTHON="$QPKG_ROOT/python/bin/python3"
LAUNCHER="$QPKG_ROOT/launcher.py"
case "${1:-}" in
 start)
  ENABLED=$(/sbin/getcfg "$QPKG_NAME" Enable -u -d FALSE -f /etc/config/qpkg.conf)
  [ "$ENABLED" = TRUE ] || exit 1
  "$PYTHON" -I -S "$LAUNCHER" --status >/dev/null 2>&1 && exit 0
  "$PYTHON" -I -S "$LAUNCHER" --initialize
  "$PYTHON" -I -S "$LAUNCHER" --supervise >>"$QPKG_ROOT/var/runtime.log" 2>&1 </dev/null &
  PCC_ATTEMPT=0
  while [ "$PCC_ATTEMPT" -lt 20 ]; do
   sleep 1
   if "$PYTHON" -I -S "$LAUNCHER" --status >/dev/null 2>&1; then exit 0; fi
   PCC_ATTEMPT=$((PCC_ATTEMPT+1))
  done
  exit 1
  ;;
 stop|remove) "$PYTHON" -I -S "$LAUNCHER" --stop ;;
 restart) "$0" stop; "$0" start ;;
 *) exit 2 ;;
esac
